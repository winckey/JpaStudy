package jpabook.jpashop.domain;

public enum DeliveryStaus {
    READY , COMP
}
