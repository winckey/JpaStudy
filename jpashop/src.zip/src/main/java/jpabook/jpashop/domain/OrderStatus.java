package jpabook.jpashop.domain;

public enum OrderStatus {


    ORDER_STATUS,CLORDER_STATUS
}
